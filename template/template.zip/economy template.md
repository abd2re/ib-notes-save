---
tags: [economy] 
---
Created: {{date}}

# {{title}}
?
