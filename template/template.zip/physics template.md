---
tags: [physics] 
---
Created: {{date}}

# {{title}}
